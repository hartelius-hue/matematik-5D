# Matematikværkstedet · 5.D

Et komplet statisk træningssite til matematik i 5. klasse, opdelt efter de 13 fagområder i **MULTI 5**. Materialet er selvstændigt produceret og er **ikke en officiel Gyldendal-udgivelse**.

## Indhold

- **13 kapitler** i MULTI 5's rækkefølge.
- **4 spil pr. kapitel = 52 spil**. Hvert spil har **3 niveauer** (i alt 156 valgmuligheder).
- **7 opgaver pr. runde** med nye tal og variationer, hvor det er relevant.
- Tydeligt **læringsmål før træning, under spillet og ved opsamlingen**.
- **To forsøg pr. opgave**: efter første fejl får eleven et tip; efter næste fejl vises det rigtige svar med forklaring.
- **Matematikhjælper** med opgavespecifikt tip, et separat gennemregnet eksempel og fagord.
- **Faglig læsning** med en original læsetekst og fire spil om ordforråd, tekstopgaver, spørgsmål og løsningsstrategier.
- Layout til både computer og mobil med nye 3D-bannere og en 3D-hjælper.
- **Lokal øvehistorik** på enheden, uden login, elevnavn eller server.

## Udgivelse på GitHub Pages

1. Opret et **nyt, offentligt repository** på GitHub, fx `matematik-5d`. Lad det være adskilt fra læsesitet til 3.C.
2. Pak ZIP-filen ud, og upload **indholdet** af mappen til roden af repositoryet: `index.html`, `style.css`, `app.js`, `gamebank.js`, `assets/`, `.nojekyll` og evt. `README.md`. Upload altså ikke ZIP-filen som én fil.
3. Klik **Commit changes** på GitHub.
4. Åbn repositoryets **Settings → Pages**. Vælg **Deploy from a branch**, branch **main** og mappe **/(root)**. Gem indstillingen.
5. Når GitHub har offentliggjort sitet, viser Pages den korrekte adresse. For repositorynavnet `matematik-5d` under kontoen `hartelius-hue` vil adressen normalt være `https://hartelius-hue.github.io/matematik-5d/`.
6. Ved rettelser kan filerne opdateres i det samme repository. Besøgende kan efter offentliggørelsen behøve at genindlæse siden.

**Du kan prøve sitet lokalt:** Åbn `index.html` efter udpakning i en moderne browser. Der kræves ingen installation eller server for almindelig brug.

## Filer

| Fil | Funktion |
| --- | --- |
| `index.html` | Startside og HTML-struktur |
| `style.css` | Responsive skærme, bannere, kort og spildesign |
| `gamebank.js` | Spiloversigt, matematiske generatorer og feedback (52 spil) |
| `app.js` | Navigation, interaktion, resultater, matematikhjælper |
| `assets/*.webp` | Nye 3D-illustrationer og hjælpefigur |
| `assets/favicon.svg` | Site-ikon |
| `.nojekyll` | Fortæl GitHub Pages, at der er tale om almindelige statiske filer |

## Overblik over kapitler

1. Faglig læsning
2. Regning med tal
3. Gange og division
4. Figurer, flader og linjer
5. Brøker og decimaltal
6. Cirkler og polygoner
7. Koordinatsystemet
8. Procent
9. Statistik
10. Rumfang
11. Reduktion, ligninger og uligheder
12. Tal på sandsynlighed
13. Matematik i hverdagen

## Anvendelse og databeskyttelse

Sitet er lavet til selvstændig træning og samtale om matematiske strategier. Resultatet efter hver runde tæller antallet af opgaver, som eleven løste korrekt **i første forsøg**. Et korrekt svar efter hjælp registreres særskilt. Derfor må resultatet ikke sidestilles med en standardiseret faglig test.

Fremskridt gemmes kun i browserens `localStorage`; de er ikke knyttet til bestemte elever på delte enheder. Data sendes ikke til en server. Under **Til voksne** kan den lokale øvehistorik nulstilles. Grafiske bannere er originale 3D-illustrationer, og matematikopgaverne er selvstændigt udformet.

## Teknisk

Almindelig HTML, CSS og JavaScript. **Ingen npm-pakker, databaser, cookies, tracking eller API-nøgler**. Kan hostes gratis via GitHub Pages. Sitet er testet på desktop- og mobilstørrelse samt ved generering af 12.480 opgaver og opstart af alle 156 spil/niveau-kombinationer. Faglig kontrol bør fortsætte, når eleverne tager det i brug, særligt hvis nye opgavetyper tilføjes.
